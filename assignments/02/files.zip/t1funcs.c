// returns the sum of the two arguments
int sum(int int1, int int2) {
  return int1 + int2;
}

// returns the quotient of the two arguments
int qtt(int int1, int int2) {
  return int1 / int2;
}

