// author: <First name, last name; YOUR SFU USER ID HERE>
// date: 
// input: 
// output: 
// description: 

#include <stdio.h>

int main(int argc, char* argv) {
    // argc = 3
    // argv array of 3 char arrays

    //a whole lot of code

    return 0;
}

// input --> function 