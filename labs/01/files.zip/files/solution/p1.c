// author: <First name, last name; YOUR SFU USER ID HERE>
// date: 2021-05-18
// input: void
// output: int
// description: prints a greeting to standard output.

#include <stdio.h>

int main(void) {
    printf("Hello World\n");
    printf("How are you?\n");
    return 0;
}