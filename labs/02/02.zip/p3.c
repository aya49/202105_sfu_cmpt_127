// author: <First name, last name; YOUR SFU USER ID HERE>
// date: 
// input: 
// output: 
// description: 

#include <stdio.h>
#include <string.h> // strlen(): look it up!

void contains(char* str1, char* str2) {
    // FILL IN BODY
}


int main(int argc, char* argv[]) {
    contains(argv[1], argv[2]);
    return 0;
}