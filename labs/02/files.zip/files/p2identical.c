int identical(int arr1[], int arr2[], unsigned int len) {
    // FILL IN BODY
}

int scrambled(int arr1[], int arr2[], unsigned int len) {
    // FILL IN BODY
    return 0;
}