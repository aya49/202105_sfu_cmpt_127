int identical(int arr1[], int arr2[], unsigned int len);
int scrambled(int arr1[], int arr2[], unsigned int len);