// author: <First name, last name; YOUR SFU USER ID HERE>
// date:
// input:
// output:
// description:

#include <stdio.h> // getchar, EOF constant
#include <ctype.h> // isalpha

int main() {
    // FILL IN BODY
    return 0;
}